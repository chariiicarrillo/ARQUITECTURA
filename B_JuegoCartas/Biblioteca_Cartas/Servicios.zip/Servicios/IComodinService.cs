namespace Biblioteca_Cartas.Servicios
{
    public interface IComodinService
    {
        void ComodinMaquina(System.Collections.Generic.List<Biblioteca_Cartas.Clases.Carta> cartasMaquina, Biblioteca_Cartas.Clases.Resto resto);
    }
}
