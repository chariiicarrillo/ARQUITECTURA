namespace Biblioteca_Cartas.Servicios
{
    public interface IASControlService
    {
        void ControlAS(System.Collections.Generic.List<Biblioteca_Cartas.Clases.Carta> cartasJugador);
    }
}
