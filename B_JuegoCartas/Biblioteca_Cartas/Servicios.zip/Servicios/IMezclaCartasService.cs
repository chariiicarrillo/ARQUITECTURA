namespace Biblioteca_Cartas.Servicios
{
    public interface IMezclaCartasService
    {
        System.Collections.Generic.List<Biblioteca_Cartas.Clases.Carta> MezclarCartas(System.Collections.Generic.List<Biblioteca_Cartas.Clases.Carta> cartas);
    }
}
